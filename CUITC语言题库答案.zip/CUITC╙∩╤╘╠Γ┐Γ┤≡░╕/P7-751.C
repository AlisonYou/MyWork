#include <stdio.h>
void main()
{
	int  i,k,m,n=0,xx[100];
	printf("input a number:");
	scanf("%d",&m);
	if(m<=0)
	{
		printf("error");
		return;
	}
	for(i=2;i<m;i++)
	{
		for(k=2;k<=i/2;k++)
			if(i%k==0)
				break;
		if(k>i/2)
			xx[n++]=i;
		if(n>100)
		{
			printf("overflow");
			return;
		}
	}
	printf("n=%d\n",n);
	for(i=0;i<n;i++)
	{
		printf("%5d",xx[i]);
		if((i+1)%15==0)
			printf("\n");

	}
}