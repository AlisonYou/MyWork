#include <stdio.h>

void main()
{
	float F,c;
	printf("Input the degree:");
	scanf("%f",&F);
	c=5*(F-32)/9;
	printf("\nF(%.2f)=C(%.2f)",F,c);
}
