#include <stdio.h>

int main(void)
{
	char curChar, last='N';

	printf("Please input the letter of someday: ");
	while (1)
	{
		if ('N' == last)
		{
			curChar = getchar();
		}
		else
		{
			last = 'N';  //�����ϴ��������ַ��ѱ�ʹ�ã���curChar�е��ַ�û�����¶�������ֱ��ʹ��
		}


		if ('Y' == curChar)
		{
			break;
		}

		switch (curChar)
		{
			case 'M':
				printf("Monday\n");
				break;
			case 'W':
				printf("Wednesday\n");
				break;
			case 'F':
				printf("Friday\n");
				break;

			case 'T':
				curChar = getchar();
				if ('u' == curChar)
				{
					printf("Tuesday\n");
				}
				else if ('h' == curChar)
				{
					printf("Thrusday\n");
				}
				else
				{
					printf("data error\n");
					last = 'Y';  //��ʾcurChar�е��ַ���δ��ʹ�ã��´β�Ӧ�ٶ�
				}
				break;

			case 'S':
				curChar = getchar();
				if ('a' == curChar)
				{
					printf("Saturday\n");
				}
				else if ('u' == curChar)
				{
					printf("Sunday\n");
				}
				else
				{
					printf("data error\n");
					last = 'Y'; 
				}
				break;
				
			default:
				printf("data error\n");
		}
	}

	return 0;
}