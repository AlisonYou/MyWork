#include <stdio.h>
#define M 20

void main()
{
	int m,n;
	int i,j;
	int a[M][M];
	int max,b[M]={0};
	printf("�������m*n");
	scanf("%d%d",&m,&n);
	printf("����һ��%d��%d�еľ���",m,n);
	for(i = 0;i<m;i++)
		for(j = 0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	for(i = 0;i<m;i++)
	{
		max = a[i][0];
		for(j = 1;j<n;j++)
		{
			if(max<a[i][j])
			{
				max = a[i][j];
				b[i] = j;
			}
		}
	}
	for(i = 0;i<m;i++)
	{
		printf("The max value in line %d is %d\n",i,b[i]);
	}

}