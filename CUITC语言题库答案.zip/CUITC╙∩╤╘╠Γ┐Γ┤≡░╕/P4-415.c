#include<stdio.h>

float pinjun(int a[6])
{
	int i,max=a[0],min=a[0];
	float sum=0;
	for(i=0;i<6;i++)
	{
		if(max<a[i])
			max=a[i];
		if(min>a[i])
			min=a[i];
		sum+=a[i];
	}
	sum=sum-max-min;
	return (float)(sum/4.);
}

int main()
{
	int i,j,f[10][6],a[10]={1,2,3,4,5,6,7,8,9,10},itmp;
	float p[10],ftmp;
	printf ("Please input singer's score: ");
	for(i=0;i<10;i++)
		for(j=0;j<6;j++)
			scanf("%d",&f[i][j]);

	for(i=0;i<10;i++)
	{
		p[i]=pinjun(f[i]);
	}

	printf("\nscores:\n");
	for(i=0;i<10;i++)
	{
		for(j=0;j<10-i-1;j++)
		{
			if(p[j]<p[j+1])
			{
				ftmp=p[j];
				p[j]=p[j+1];
				p[j+1]=ftmp;
				itmp=a[j];
				a[j]=a[j+1];
				a[j+1]=itmp;
			}
		}
	}

	for(i=0;i<10;i++)
		printf("No.%d:%.2f\n",a[i],p[i]);
}