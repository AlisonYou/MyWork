#include <stdio.h>
#define Pi 3.14

void main()
{
    float r,h,C1,S,V;
	
	printf("Input: ");
	scanf("r=%f,h=%f",&r,&h);
	C1=(float)(2*Pi*r);
	S=(float)(Pi*r*r);
	V=S*h;
	printf("C1=%.2f\n",C1);
	printf("S=%.2f\nV=%.2f\n",S,V);
}
