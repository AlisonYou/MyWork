#include <stdio.h>
void main()
{
	int a,b,c;
	printf("please input x,y:\n");
	scanf("%d,%d",&a,&b);

	if(a>b)
		c=a;
	else
		c=b;

	printf("%d is bigger",c);
}
