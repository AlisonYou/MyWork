#include<stdio.h>
#include<string.h>

void main()
{
	char s[127],h[127];
	int i,l,flag=1;

	gets(s);
	l=strlen(s);

	for(i=0;i<l/2;i++)
	{
		if(s[i]!=s[l-i-1])
		{
			flag=0;
			break;
		}
	}

	for(i=0;i<l;i++)
	{
		h[i]=s[l-i-1];
	}
	h[i]='\0';

	if(flag)
		printf("\n%s shi hui wen.",h);
	else
		printf("\n%s bu shi hui wen.",s);



}