#include<stdio.h>

int main(void)
{
        /*********Found************/
        char yy[100] = "ok??\n";

        /*********Found************/
        printf("%s", yy);

	return 0;
}
