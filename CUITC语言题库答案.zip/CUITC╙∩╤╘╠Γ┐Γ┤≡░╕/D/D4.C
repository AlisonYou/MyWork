#include<stdio.h>

#define PI 3.14
/*********Found************/
#define S(bj) PI*(bj)*(bj)

int main(void)
{
        /*********Found************/
        double mianJi;

        mianJi = S(2+3);
        printf("mian ji=%5.2f\n", mianJi);

	return 0;
}
