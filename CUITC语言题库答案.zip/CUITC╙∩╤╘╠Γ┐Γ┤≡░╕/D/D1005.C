#include<stdio.h>

int main(void)
{
	int a, b;

	/*********Found*********/
	scanf("%d,%d", &a, &b);
	/*********Found*********/
	printf("a=%d,b=%d\n", a, b);

	return 0;
}
