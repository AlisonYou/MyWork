#include<stdio.h>

int main(void)
{
        /*********Found************/
        char yy[128];

        /*********Found************/
        gets(yy);

        /*********Found************/
        printf("%s", yy);

	return 0;
}
