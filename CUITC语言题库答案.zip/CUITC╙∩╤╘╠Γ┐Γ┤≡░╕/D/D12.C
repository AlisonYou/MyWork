#include<stdio.h>

int main(void)
{
        int a, b;

        /*********Found************/
        scanf("%d,%d", &a, &b);
        while (b > 0)
        /*********Found************/
        {

                printf("%d\n", a);
                b--;
        /*********Found************/
        }

        printf("bye bye!\n");

	return 0;
}
