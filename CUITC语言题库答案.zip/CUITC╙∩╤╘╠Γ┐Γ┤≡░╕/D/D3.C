#include<stdio.h>

int main(void)
{
        /*********Found************/
        char *yy = "ok??\n";

        /*********Found************/
        for (; *yy; yy++)
        {
                putchar(*yy);
        }

	return 0;
}
