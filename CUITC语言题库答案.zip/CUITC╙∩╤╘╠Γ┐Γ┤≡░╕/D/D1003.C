#include<stdio.h>

int main(void)
{
	/*****Found*****/
	int i = 0x100;

	/*****Found*****/
	printf("%d\n", i);

	return 0;
}
