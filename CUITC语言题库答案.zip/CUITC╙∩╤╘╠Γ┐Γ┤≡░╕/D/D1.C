#include<stdio.h>

int main(void)
{
        int xy2;

        /*********Found************/
        scanf("%d", &xy2);
        /*********Found************/
        printf("xy2=%5d\n", xy2);

	return 0;
}
