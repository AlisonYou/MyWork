#include<stdio.h>

int main(void)
{
        /*********Found************/
        int x, y;

        x = 39270;
        y = 41001;
        /*********Found************/
        if (x == y)
        {
                printf("x=y");
        }
        /*********Found************/
        else
        {
                printf("x<>y\n");
        }

	return 0;
}
