#include<stdio.h>

/*********Found************/
#define START {
/*********Found************/
#define NEXT  }

int main(void)
{
        char *str2 = "13125176247";
        const int i = 0;

        for (printf("\n"); str2[i]; )
        START
                putchar(str2[i]);
                /*********Found************/
                str2++;
        NEXT

	return 0;
}
