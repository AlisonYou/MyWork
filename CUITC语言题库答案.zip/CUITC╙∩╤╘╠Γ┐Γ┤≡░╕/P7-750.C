#include <stdio.h>
void main()
{
	char s[80];
	int i,j;
	gets(s);
	for(i=j=0;s[i]!='\0';i++)
		if(s[i]!='*')
			s[j++]=s[i];
	s[j]='\0';
	puts(s);
}