#include <stdio.h>
#include <math.h>
int main()
{
	int side;
	int circle;
	double area,halfcircle;
	printf("Input a side of triangle: ");
	scanf("%d",&side);
	circle=3*side;
	halfcircle=circle/2.0;
	area=sqrt(halfcircle*(halfcircle-side)*(halfcircle-side)*(halfcircle-side));
	printf("The area of triangle is %.2f, the circle of triangle is %d.\n",area,circle);

}