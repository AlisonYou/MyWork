#include <stdio.h>

int main(void)
{
	int x;
	double Fx;

	printf("\nPlease input x:");
	scanf("%d", &x);

	Fx = (x < 0)? -5.0 * x + 27 : ((!x)? 7909 : 2.0 * x - 1);

	printf("\nF(%d) = %.0f", x, Fx);
	return 0;
}
