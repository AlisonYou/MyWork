#include<stdio.h> 
void main() 
{ 
	int day,x1,x2; 
	printf("Please input n:");
	scanf("%d",&day);
    x2=1; 
    while(day>1) 
	{ 
		x1=(x2+1)*2; 
        x2=x1; 
        day--; 
	} 
    printf("total=%d\n",x1); 
} 