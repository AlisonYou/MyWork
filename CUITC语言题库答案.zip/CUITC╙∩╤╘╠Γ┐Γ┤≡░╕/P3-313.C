#include <stdio.h>
void main()
{
	int a[20][30],m,n,i,j,k,x,y,max,min;
	int count=0;
	printf("Please input m and n:");
	scanf("%d%d",&m,&n);
	printf("Please input a juZhen(%d hang,%d lie):\n",m,n);
	for(i=0;i<m;i++)
		for(j=0;j<n;j++)
			scanf("%d",&a[i][j]);
	/*for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		printf("%8d",a[i][j]);
		printf("\n");
	}*/
	for(i=0;i<m;i++)
	{
		max=a[i][0];
		y=0;
		for(k=1;k<n;k++)
			if(max<a[i][k])
			{
				y=k;
				max=a[i][k];
			}
		x=i;
		min=a[i][y];
		for(k=0;k<m;k++)
			if(min>a[k][y])
			{
			
				min=a[k][y];
				x=k;			
			}
	
	    if(i==x)
		{
		   printf("you an dian, wei: juZhen[%d][%d]=%d\n",x,y,a[x][y]);
		   count++;
		}
 
	}
	if(count==0)
	{
		printf("mei you an dian.\n");
	}
}