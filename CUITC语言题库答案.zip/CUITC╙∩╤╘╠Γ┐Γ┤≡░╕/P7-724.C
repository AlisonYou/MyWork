#include  <stdio.h>

void main()
{
	int  i,j,r,n;
	
	printf("\ninput a number(1~9):");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=i;j++)
		{
				r=i*j;
				printf("%d*%d=%-3d",i,j,r);
		}
		printf("\n");
	 }
}
