#include<stdio.h>
#include<string.h>

int main()
{
	char s[128];
	char c;
	unsigned int i;
	int zimu=0,shuzi=0,kongge=0,qita=0;
	printf("Please input string:");
	gets(s);

	//��s�е����ֿ�����t��
	for(i=0;i<strlen(s);i++)
	{
		c=s[i];
		if(c>='0' && c<='9')
			shuzi++;
		else if((c>='a' && c<='z') || (c>='A' && c<='Z'))
			zimu++;
		else if(c==' ')
			kongge++;
		else
			qita++;
	}

	printf("\nzimu=%d,shuzi=%d,kongge=%d,qita=%d\n",zimu,shuzi,kongge,qita);

	return 0;
}