#include <string.h>
#include <stdio.h>

void main()
{
	char st[80],name[5][80]; 
	int i,j;
	
	printf("Input 5 strings:\n");
	for(i=0;i<5;i++)  gets(name[i]); 
	for(i=1;i<5;i++)
		for(j=0;j<5-i;j++)
			if(strcmp(name[j],name[j+1])>0)
			{        strcpy(st,name[j]);
			strcpy(name[j],name[j+1]);
			strcpy(name[j+1],st);
			}
			
			printf("---------------------------\n");
			for(i=0;i<5;i++)  
			{
				puts(name[i]);
				//	 putchar('\n');
			}
} 
