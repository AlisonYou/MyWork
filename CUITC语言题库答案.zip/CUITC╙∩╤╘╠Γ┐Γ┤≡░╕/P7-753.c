#include <stdio.h>
#include <math.h>

int main(void)
{
	int i, y, y1;
	double x, xPowY=1.0;

	printf("Input x, y: ");
	scanf("%lf,%d", &x, &y);

	y1 = abs(y);
	for (i=1; i<=y1; i++)
	{
		xPowY = xPowY * x;
	}
	if (y < 0)
	{
		xPowY = 1 / xPowY;
	}

	printf("%f^%d=%f\n", x, y, xPowY);
	return 0;
}
