#include <stdio.h>
void main()
{
	int i,j,n,a[5][5];
	printf("Please input an integer:");
	scanf("%d",&n);
	for(i=0;i<5;i++)
		for(j=0;j<5;j++)
			a[i][j]=n+i+j;
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
			printf("%4d",a[i][j]);
		printf("\n");
	}
}