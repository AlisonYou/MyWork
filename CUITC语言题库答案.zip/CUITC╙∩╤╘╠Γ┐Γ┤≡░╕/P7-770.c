/*********************************************************************************
*   Purpose: ʵ��ʮ����ת����R������	2<= R <= 16 & RΪ����					 *
**********************************************************************************/
#include<stdio.h >

int main(void)
{
	/*R��������*/
	int n, i = 0, jzR, Res[60] = { 0 };
	char str[17] = "0123456789ABCDEF";

	printf("input the num, R: ");
	scanf("%d,%d", &n, &jzR);

	printf("Result: \n");
	if (n < 0)
	{
		printf("%c" , '-');
		n = -n;
	}

	while (n != 0)
	{
		Res[i++] = n % jzR;
		n = n / jzR;
	}

	while (i-- > 0)
	{
		printf("%c", str[Res[i]]);
	}
	printf("\n");

	return 0;
}
