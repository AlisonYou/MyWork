#include<stdio.h>
#include<stdlib.h>

#define LEN sizeof(struct Data)

struct Data
{
	int num;
	float score;
	struct Data *next;
};	

void printChain(struct Data *cur);
/* userCode(<100�ַ�): �Զ��庯��֮ԭ������ */
struct Data *insert(struct Data *head,int num,float score);
struct Data *delodd(struct Data *head);
int sum=0;
int main(void)
{	
	struct Data *head = NULL;
	int num;
	float score;

	printf("Please input node data:\n");
	scanf("%d %f", &num, &score);
	while (num != 0)
	{
		head = insert(head, num, score);
		scanf("%d %f", &num, &score); 
	}
	
	printf("\nOutput whole nodes of the chain:\n");
	printChain(head);
	
	return 0;
};

void printChain(struct Data *cur)
{
	printf("Result: ");
	while (cur != NULL)
	{
		printf("%d-%.2f  ", cur->num, cur->score);
		cur = cur->next;
	}
	putchar('\n');
}

/* User Code Begin�������ڴ˺�����Զ��庯������ƣ��������� */
struct Data *insert(struct Data *head,int num,float score)
{ 
	int i=0;

	//float tmpscore;
	struct Data *p1,*p2;
	p1=p2=(struct Data*)malloc(LEN);

	p1->num=num;
	p1->score=score;
	p1->next=NULL;
	sum++;

	if(head==NULL)
	{
		head=p1;
		p2=p1;
	}
	else
	{
		p2=head;
		
	}

	head=delodd(head);
	
	return head;
}

struct Data *delodd(struct Data *head)
{
	struct Data *p;
	int i,tmpnum;
	float tmpscore;
	for(i=0; i<sum; i++)
	{
		p=head;
		while (p->next != NULL)
		{
			if (p->num > p->next->num)
			{
				tmpnum = p->num;
				p->num = p->next->num;
				p->next->num = tmpnum;

				tmpscore = p->score;
				p->score = p->next->score;
				p->next->score = tmpscore;
			}
			p = p->next;
		}
	}

	return head;
}
/*
	while(1)
	{
		sum++;
		//scanf("%d%f",&p1->num,&p1->score);
	
		if(p1->num == 0 && p1->score==0)
		{
			break;
		}
		
		if(head==NULL)
		{
			head=p1;
		}
		else
		{
			p2->next=p1;
		}
		p2=p1;
		p1=(struct Data*)malloc(LEN);
	
	}
	p2->next=NULL;
	
	for(i=1; i<sum; i++)
	{
		p=head;
	while(p->next != NULL)
	{
		if(p->num >p->next->num)
		{
			tmpnum=p->num;
			p->num=p->next->num;
			p->next->num=tmpnum;

			tmpscore=p->score;
			p->score=p->next->score;
			p->next->score=tmpscore;
		}
		p=p->next;
	}
	}
	return head;
}*/