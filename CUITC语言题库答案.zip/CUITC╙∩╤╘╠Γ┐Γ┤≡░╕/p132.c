#include <stdio.h>

int main(void)
{
	printf("I can printf \\n,\"\\t & \\!");
	return 0;
}