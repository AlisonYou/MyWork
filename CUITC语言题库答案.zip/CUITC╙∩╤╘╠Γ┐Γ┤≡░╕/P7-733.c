#include <stdio.h>
int main()
{
	char ch;
	printf("Input a character: ");
	ch=getchar();
	printf("%x\n",ch);
	return 0;
}