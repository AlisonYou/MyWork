#include <stdio.h>
void main()
{
	int a,b;
	printf("please input data:");
	scanf("%d%d",&a,&b);
	printf("%3d+%3d=%3d",a,b,a+b);
}