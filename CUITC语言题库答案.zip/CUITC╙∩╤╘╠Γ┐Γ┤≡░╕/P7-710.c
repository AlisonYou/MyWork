#include <stdio.h>

void main()
{
	char ch;
	
	printf("Input a lowercase letter:");
	ch=getchar();
	printf("\n%c(%d)",ch,ch);
	ch -= 'a'-'A';
	printf("\n%c(%d)",ch,ch);
}