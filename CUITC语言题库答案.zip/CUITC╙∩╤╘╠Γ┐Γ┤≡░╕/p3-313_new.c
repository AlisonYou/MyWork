#include <stdio.h>

int main(void)
{
	int i, j, k, m, n, flag;
	int saddle, saddlei, saddlej;
	int array[20][20];

	printf("Please input m and n:");
	scanf("%d%d", &m, &n);
	printf("Please input a juZhen(%d hang, %d lie):\n", m, n);
	for (i = 0; i < m; i++)
	{
		for (j = 0; j < n; j++)
		{
			scanf("%d", &array[i][j]);
		}
	}
	for (i = 0; i < m; i++)
	{
		flag = 0;
		saddle = array[i][0];
		for (j = 0; j < n; j++)
		{
			if (saddle < array[i][j])
			{
				saddle = array[i][j];
				saddlei = i;
				saddlej = j;
			}
		}
		for (k = 0; k < m; k++)
		{
			if (saddle > array[k][saddlej])
			{
				flag = 1;
			}
		}
		if (flag == 0)
		{
			break;
		}
	}

	if (flag == 1)
	{
		printf("\nmei you an dian.\n");
	}
	else
	{
		printf("\nyou an dian, wei: juZhen[%d][%d]=%d\n", saddlei, saddlej, saddle);
	}
	return 0;
}