#include<stdio.h>
void main()
{
	long benjin;
	int cunqi;

	printf("please input benjin,cunqi:");

	scanf("%ld,%d",&benjin,&cunqi);

	switch(cunqi)
	{
	case 1: printf("\nlixi = %0.2f yuan",benjin*0.0315*1); break;

	case 2: printf("\nlixi = %0.2f yuan",benjin*0.0363*2); break;

	case 3: printf("\nlixi = %0.2f yuan",benjin*0.0402*3); break;
 
	case 5: printf("\nlixi = %0.2f yuan",benjin*0.0469*5); break;

	case 8: printf("\nlixi = %0.2f yuan",benjin*0.0536*8); break;

	default:  printf("input right cunqi");
	}
}