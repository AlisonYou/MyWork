                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
#include <stdio.h>

/* userCode(<50�ַ�): �Զ��庯��֮ԭ������ */
int find(int in[], int in1); 

int main(void)
{
	int arrA[5], arrB[8], minA, minB;

	printf("������5������");
	scanf("%d%d%d%d%d", &arrA[0], &arrA[1], &arrA[2], &arrA[3], &arrA[4]);
	printf("������8������");
	scanf("%d%d%d%d%d%d%d%d", &arrB[0], &arrB[1], &arrB[2], &arrB[3], &arrB[4], &arrB[5], &arrB[6], &arrB[7]);

	minA = find(arrA, 5);  /* userCode(<30�ַ�): ���ú�������arrA��Ԫ�ص���Сֵ */
	printf("\nMin(arrA) = %d", minA);
	minB = find(arrB, 8);  /* userCode(<30�ַ�): ���ú�������arrB��Ԫ�ص���Сֵ */
	printf("\nMin(arrB) = %d\n", minB);

	return 0;
}

/* User Code Begin�������ڴ˺�����Զ��庯������ƣ��������� */
int find(int in[], int in1)
{
	int in2, temp = in[0];
	
	for (in2  = 1; in2 < in1; in2++)
	{
		if (temp > in[in2])
		{
			temp = in[in2];

		}
	}
	return temp;
} 


