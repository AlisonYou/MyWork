#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	int data1 = 0, data2 = 0;
	int i;
	double result;
	char op;

	if (argc != 4)
	{
		printf("\nusage:P1-115  num1 op num2\n");
		return 1;
	}

	if (strlen(argv[2]) > 1)
	{
		printf("\nop(%s) Error!\n", argv[2]);
		return 2;
	}

	for (i = 0; argv[1][i] != '\0'; i++)
	{
		data1 = data1 * 10 + argv[1][i] - '0';
	}

	for (i = 0; argv[3][i] != '\0'; i++)
	{
		data2 = data2 * 10 + argv[3][i] - '0';
	}

	op = argv[2][0];
	switch (op)
	{
		case '+':
			result = data1 + data2;
			break;
		case '-':
			result = data1 - data2;
			break;
		case '*':
			result = data1 * data2;
			break;
		case '/':
			result = (double)data1 / data2;
			break;
		case '%':
			result = data1 % data2;
			break;
		default:
			printf("\nop(%c) Error!\n", op);
			return 2;
	}

	if (op != '/')
	{
		printf("\n%d %c %d = %.0f", data1, argv[2][0], data2, result);
	}
	else
	{
		printf("\n%d %c %d = %.2f", data1, argv[2][0], data2, result);
	}
	return 0;
}