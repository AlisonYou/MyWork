#include<stdio.h>

int main()
{
	char s[128],c;
	int i=0;
	printf("Please input string: ");

	while((c=getchar())!='\n')
	{
		if(c>='a' && c<='z')
		{
			if((c-'a')<13)
				s[i++]=c+(26-2*(c-'a')-1);
			else
				s[i++]=c-(26-2*('z'-c)-1);
		}
		else if(c>='A' && c<='Z')
		{
			if((c-'A')<13)
				s[i++]=c+(26-2*(c-'A')-1);
			else
				s[i++]=c-(26-2*('Z'-c)-1);
		}
		else
			s[i++]=c;
	}

	s[i]='\0';

	printf("\nzi fu chuan chang du:%d\n",i);
	printf("\nmi wen:%s",s);
	return 0;
}