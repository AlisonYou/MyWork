#include <stdio.h>

void main()
{
      int k,n;
      double f[21];

       f[0]=0L;
       f[1]=1L; 
       f[2]=2L;
       printf("Input n (13>=n>=2):");
       scanf("%d",&n);
       for (k=2; k<n; k++)
              f[k+1]=2*f[k]+f[k-1]*f[k-2];
    
	printf("\nf(%d)=%.0lf\n",n,f[n]);
}