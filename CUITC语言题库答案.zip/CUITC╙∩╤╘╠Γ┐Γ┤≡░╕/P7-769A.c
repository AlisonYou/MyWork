#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>

int isHuiwen(int temp);
int isSushu(int temp);

int main(void)
{
	int m, n;

	printf("please input m, n(5<=m<=n<=100000): ");
	scanf("%d,%d", &m, &n);

	printf("Result(%d-%d):\n", m, n);
	while (m <= n)
	{
		if (isHuiwen(m))
		{
			if (isSushu(m))
			{
				printf("%d ", m);
			}
		}
		m++;
	}
	printf("\n");

	return 0;
}

int isHuiwen(int temp)
{
	char str1[100], str2[100];

	itoa(temp, str1, 10);
	strcpy(str2, str1);
	strrev(str2);
	if (strcmp(str1, str2) == 0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int isSushu(int temp)
{
	/*ѭ������*/
	int i;
	/*�ж��Ƿ�������*/
	for (i=2; i<=sqrt((double)temp); i++)
	{
		if (temp%i == 0)
		{
			return 0;
		}
	}
	return 1;
}
