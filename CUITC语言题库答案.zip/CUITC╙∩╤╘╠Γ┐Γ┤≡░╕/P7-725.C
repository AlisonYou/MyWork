#include<stdio.h>
#define N 20
void main()
{
	int  f[N] = {1,1};
	int  m,i;
	
	printf("input a data(3--20):");
	scanf("%d",&m);

	for (i=2; i<m; i++)
	{
		f[i] = f[i-1] + f[i-2]; 
	}

	for (i=0; i<m; i++)
	{
		printf("%d", f[i]);
		if(i<m-1)
		printf("\t");
	}
	     
}
