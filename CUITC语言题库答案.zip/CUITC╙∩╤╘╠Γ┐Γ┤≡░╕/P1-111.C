#include<stdio.h>

void main()
{
	int x;
	double F;
	printf("Please input x: ");
	scanf("%ld",&x);

	if(x<0)
		F=-5*(double)x+27;
	else if(x==0)
		F=7909;
	else
		F=2*(double)x-1;
		

	printf("\nF(%d) = %.0lf\n", x,F);
}