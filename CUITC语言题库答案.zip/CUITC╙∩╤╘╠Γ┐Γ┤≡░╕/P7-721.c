#include <stdio.h>

void main()
{
	float x,y,r;
	int z;

	
	printf("please input x,y,z:");
	scanf("%f,%f,%d",&x,&y,&z);
	r=x+z%3*(int)(x+y)%2/4;
	printf("%f",r);
}