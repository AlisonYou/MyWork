#include <stdio.h>

int main(void)
{
	int benjin, cunqi;
	double lixi, liLv[]={0, 3.15, 3.63, 4.02, 0, 4.69, 0, 0, 5.36};

	printf("\nPlease input benjin,cunqi:");
	scanf("%d,%d", &benjin, &cunqi);

	lixi = benjin * liLv[cunqi] / 100 * cunqi;
	printf("\nlixi = %.2f yuan\n", lixi);

	return 0;
}