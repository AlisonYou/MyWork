#include <stdio.h>
int main()
{
	float salary=500;
	int profit;
	printf("Input  profit: ");
	scanf("%d",&profit);

	switch((profit-1)/1000)
	{
	case 0:
		break;
	case 1:
		salary+=(float)(profit*0.1);
		break;
	case 2:
	case 3:
	case 4:
		salary+=(float)(profit*0.15);
		break;
	case 5:
	case 6:
	case 7:
	case 8:
	case 9:
		salary+=(float)(profit*0.2);
		break;
	default:
		salary+=(float)(profit*0.25);
		break;
	}
	printf("\nsalary=%0.2f\n",salary);
	return 0;
 }