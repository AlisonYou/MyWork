#include <stdio.h>
int main()
{
	int k[100];
	int i,j,n,s,m;
	
	printf("Please input an integer:");
	scanf("%d",&m);
	for(j=2;j<m;j++)
	{
		n=-1;
		s=j;
		for(i=1;i<j;i++)
		{
			if((j%i)==0)
			{
				n++;
				s=s-i;
				k[n]=i;
			}
		}
		if(s==0)
		{
			printf("%6d is a wanshu",j);
			for(i=0;i<=n;i++)
				printf("%5d",k[i]);
			printf("\n");
		}
	}
	return 0;
}