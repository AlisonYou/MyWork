#include <stdio.h>
#include <string.h>
int main()
{
	int i;
	char a[100];
	printf("Input a string: ");
	gets(a);
	printf("The result is: ");
	for(i=strlen(a)-1;i>=0;i--)
		printf("%c",a[i]);
	printf("\n");
}