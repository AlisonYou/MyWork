#include <stdio.h>

int main()
{
	double a,b;
	printf("Input 2 numbers: ");
	scanf("%lf %lf",&a,&b);
	if(b!=0)
	{
		printf("The result is: %.2f\n",a/b);
	}
	else
	{
		printf("Divid by zero\n");
	}
}