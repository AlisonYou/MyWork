#define PRICE 30
#include <stdio.h>
void main()
{ 
	int num,total;
	printf("please input num:");
	scanf("%d",&num);
	total=num*PRICE;
	printf("total=%d\n",total);
}
