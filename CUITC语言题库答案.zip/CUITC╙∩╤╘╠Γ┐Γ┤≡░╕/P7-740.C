#include <stdio.h>
int main()
{
	int i,j,k;
	int money,number;
	printf("Input the money: ");
	scanf("%d",&money);
	printf("Input the number: ");
	scanf("%d",&number);
	printf("  cock   hen chick\n");
	for(i=0;i<=money/5;i++)
		for(j=0;j<=money/3;j++)
			for(k=0;k<=money*3;k++)
			{
				if(i+j+k==number&&15*i+9*j+k==3*money)
				{
					printf("%6d%6d%6d\n",i,j,k);
				}
			}
}