#include <stdio.h>

void main()
{ 
	float a,b;

	printf("please input two numbers:");
	scanf("%f,%f",&a,&b);
	printf("\na=%f,b=%f",a,b);
}
