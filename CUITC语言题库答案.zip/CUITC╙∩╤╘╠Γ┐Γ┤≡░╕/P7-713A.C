#include <stdio.h>

int main(void)
{
	int day, month, year, sum=0, i;
	int dayOfMon[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

	printf("Please input: year-month-day\n");
	scanf("%d-%d-%d", &year, &month, &day);

	for (i=1; i<month; i++)
	{
		sum +=  dayOfMon[i];
	}

	sum += day;
	if ((year%400==0 || year%4==0 && year%100!=0) && month>2)
	{
		sum++;
	}

	printf("\nIt is the %dth day.\n", sum);
	return 0;
}
