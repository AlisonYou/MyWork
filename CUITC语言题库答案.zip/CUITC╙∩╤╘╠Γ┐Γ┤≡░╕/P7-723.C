#include <math.h>
#include <stdio.h>

void main()
{   
		float a,b,c,s,area;
		printf("\nplease input triange sides:");
		scanf("%f,%f,%f",&a,&b,&c);
		if(a<0||b<0||c<0||((a+b)<c)||((a+c)<b)||((b+c)<a))
		{
			printf("\ndata error\n");
		}
		else
		{
			s=(float)(1.0/2*(a+b+c));
			area=(float)sqrt(s*(s-a)*(s-b)*(s-c));
			printf("\narea=%7.2f\n",area);
		}
}