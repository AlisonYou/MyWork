#include<stdio.h>
#define N 15

void main()
{
	int a[N],num,i,left,right,mid,find=0;
	left=0; right=N-1;
	printf("please input %d integer numbers( big to small):\n",N);
	for(i=0;i<N;i++) scanf("%d",&a[i]);
	printf("please input the integer you want to find:\n");
	scanf("%d",&num);
	
	while( find==0 && left<=right)
	{mid=(left+right)/2;
    if(num<a[mid]) left=mid+1;
	else if(num>a[mid]) right=mid-1;
	else find=1;
	}
	if(find==1) printf("%d has been found,it is a[%d]\n",num,mid);
	else printf("%d has not been found\n",num);
}
