#include<stdio.h>

struct student
{
	int num;
    char name[20];
	float s1,s2,s3;
	float aver;
};

int main(void)
{
	void input(struct student *p,int n);
	int highest(struct student *p,int n);

	int high;
	struct student a[5];
	input(a,5);
	high=highest(a,5);

	printf("\nThe Highest is %s(%d)\ns1=%.2f,s2=%.2f,s3=%.2f,aver=%.2f\n",
		a[high].name, a[high].num,a[high].s1, a[high].s2, a[high].s3, a[high].aver);

	return 0;
}

void input(struct student *p,int n)
{
	int i;
	struct student a;                                   //��Ҫ����Ϊa[5]
	printf("Please input student info:\n");
	printf("Num   Name   s1   s2   s3\n");
	for(i=0;i<n;i++)
	{
		printf("%d:",i+1);
		scanf("%d%s%f%f%f",&a.num,&a.name,&a.s1,&a.s2,&a.s3);
		p[i]=a;                                       //��ҪдΪp=a
		p[i].aver=(p[i].s1+p[i].s2+p[i].s3)/3.0f;     //��Ҫ©��f
	}
}

int highest(struct student *p,int n)
{
	int t,i;
	float max=0;
	max=p[0].aver;
	for(i=0;i<n;i++)
	{
		if(max<p[i].aver)
		{
			max=p[i].aver;
			t=i;
		}
	}
	return t;
}












