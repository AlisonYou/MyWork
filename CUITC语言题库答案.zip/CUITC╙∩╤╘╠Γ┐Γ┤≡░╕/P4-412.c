#include<stdio.h>
#include<string.h>

int main()
{

	int a[10000];
	int num,i,j,tmp;
	printf("Please input numbers:");
	//��������
	for(i=0;i<10000;i++)
	{
		scanf("%d",&tmp);
		if(tmp==-222)
			break;
		a[i]=tmp;
	}
	num=i;//���ֵĸ���
	
	//����
	for(i=0;i<num-1;i++)
	{
		for(j=0;j<num-i-1;j++)
		{
			if(a[j]>a[j+1])
			{
				tmp=a[j];
				a[j]=a[j+1];
				a[j+1]=tmp;
			}
		}
	}

	//���
	printf("\nOutput:\n");
	for(i=0;i<num;i++)
	{
		printf("%-6d",a[i]);
		if((i+1)%6==0)
			printf("\n");
		else if(i<num-1)
			printf(",");
	}
	//putchar('\b'); //�˸��

	return 0;
}