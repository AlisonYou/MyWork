#include<stdio.h>

int main()
{
	int d1,d2;
	char op;
	printf("Please input data1 op data2: ");
	scanf("%d %c %d",&d1,&op,&d2); // ע���ʽ�����пո�

	switch(op)
	{
	case '+':
		printf("\n%d+%d=%.0lf",d1,d2,(double)d1+(double)d2);break;
	case '-':
		printf("\n%d-%d=%.0lf",d1,d2,(double)d1-(double)d2);break;
	case '*':
		printf("\n%d*%d=%.0lf",d1,d2,(double)d1*(double)d2);break;
	case '/':
		if(d2==0)
			printf("\nError! chu shu wei 0.\n");
		else
			printf("\n%d/%d=%ld",d1,d2,d1/d2);
		break;
	case '%':
		if(d2==0)
			printf("\nError! chu shu wei 0.\n");
		else
			printf("\n%d%%%d=%ld",d1,d2,d1%d2);
		break;
	default:
		printf("\nError!");
	}
	return 0;
}