#include<stdio.h>
#define N 10

void main()
{
	int a[N],i,j,min,temp;
	printf("please input %d integer numbers:\n",N);
	for(i=0;i<N;i++)  scanf("%d",&a[i]);
	printf("the array before sorted:\n");
	for(i=0;i<N;i++) printf("%d  ",a[i]);
	printf("\n");
	for(i=0;i<N-1;i++)
	{ min=i;
	for(j=i;j<N;j++) if(a[j]<a[min]) min=j;
	temp=a[i]; a[i]=a[min];a[min]=temp;
	}
	printf("the array after sorted:\n");
	for(i=0;i<N;i++)  printf("%d  ",a[i]);
	printf("\n");
}
