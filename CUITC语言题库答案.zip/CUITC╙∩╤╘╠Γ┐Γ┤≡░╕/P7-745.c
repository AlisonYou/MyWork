#include <stdio.h>

int main()
{
	int m,n,answer1,answer2;
	printf("please input two integer numbers:\n");
	scanf("%d%d",&m,&n);
	for(answer1=m;;answer1--)
		if(m%answer1==0&&n%answer1==0) 
			break;
		for(answer2=m;;answer2++)
			if(answer2%m==0&&answer2%n==0) break;
			printf("the greatest common divisor is %d\n",answer1);
			printf("the least common multiple is %d\n",answer2);
			return 0;
}
