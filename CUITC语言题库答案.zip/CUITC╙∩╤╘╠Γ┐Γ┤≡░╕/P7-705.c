#include<stdio.h>

int main(void)
{
	char ch;
	int flag;

	printf("please input the letter of someday: ");
	ch = getchar();

	while (ch != 'Y')
	{
		flag = 0;
		switch (ch)
		{
			case 'M':
				printf("Monday\n");
				break;
			case 'W':
				printf("Wednesday\n");
				break;
			case 'F':
				printf("Friday\n");
				break;
			case 'S':
				ch = getchar();
				if (ch == 'a')
				{
					printf("Saturday\n");
					
				}
				else
				{
					if (ch == 'u')
					{
						printf("Sunday\n");
						
					}
					else
					{
						flag = 1;
						printf("data error\n");
					}
				}
				break;
			case 'T':
				ch = getchar();
				if (ch == 'u')
				{
					printf("Tuesday\n");
				}
				else
				{
					if (ch == 'h')
					{
						printf("Thursday\n");
					}
					else
					{
						flag = 1;
						printf("data error\n");
					}
				}
				break;
			default: 
				printf("data error\n");
		}
		if (flag == 0 && ch != 'Y')
		{
			ch = getchar();
		}
	}
	return 0;
}
