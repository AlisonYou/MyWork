#include <stdio.h>


void move(int *array,int n,int m);

void main()
{
	int a[100],i;
	int n,m;
	printf("the total numbers is:");
	scanf("%d",&n);
	printf("back m");
	scanf("%d",&m);

	printf("input 10 intergers:");
	for(i  = 0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	move(a,n,m);
	printf("after move %d\n",m);
	for(i = 0;i<n;i++)
	{
		printf("%-4d",a[i]);
	}
}

void move(int *array,int n,int m)
{
	int i;
	int a[100];
	for(i = 0;i<n;i++)
	{
		a[i] = array[i];
	}
	for(i = n-1;i>=m;i--)
	{
		array[i]=array[i-m];
	}
	for(i = 0;i<m;i++)
	{
		array[i] = a[n-m+i];
	}
}