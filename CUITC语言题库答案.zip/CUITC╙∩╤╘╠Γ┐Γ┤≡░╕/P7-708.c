#include<stdio.h>

void main()
{
	unsigned int d;
	int bai,shi,ge;
	
	printf("Input an integer:");
	scanf("%d",&d);
	bai=d/100;
	shi=d%100/10;
	ge=d%10;
	printf("\nThe result is %d%d%d",ge,shi,bai);
}