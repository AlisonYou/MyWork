#include <stdio.h>
#include <string.h>

struct good
{
	char name[24];
	char type[14];
	double price;
	long number;
};

int main(void)
{
	int i = 0, n, flag;
	char str[24];
	struct good goods[100];
	FILE *fp;

	fp = fopen("sp.txt", "r");
	while (!feof(fp))
	{
		fscanf(fp, "%s%s%lf%ld", goods[i].name, goods[i].type,
			&goods[i].price, &goods[i].number);
		i++;
	}
	n = i;
	flag = 0;
	printf("Please input shang pin pin ming:");
	scanf("%s", str);
	printf("\ncha zhao qing kuang:\n");
	for (i = 0; i < n; i++)
	{
		if (strcmp(goods[i].name, str)==0)
		{
			printf("%s,%s,%ld,%.2f\n", goods[i].name, goods[i].type,
				goods[i].number, goods[i].price);
			flag = 1;
		}
	}
	if (flag == 0)
	{
		printf("mei you shang pin %s\n", str);
	}
	return 0;
}