#include <stdio.h>
int main()
{
	int i,sum=0;
	int a[5],b[5];
	printf("Input A: ");
	for(i=0;i<5;i++)
		scanf("%d",&a[i]);
	printf("Input B: ");
	for(i=0;i<5;i++)
		scanf("%d",&b[i]);
	for(i=0;i<5;i++)
		sum=sum+a[i]*b[5-i-1];
	printf("sum=%d\n",sum);
}