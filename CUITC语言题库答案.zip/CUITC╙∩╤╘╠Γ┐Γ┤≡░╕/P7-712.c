#include <stdio.h>

void main()
{
	int d;
          
	printf("Please input an integer:");
	scanf("%d",&d);
	if ((d%5==0)&&(d%7==0)) 
		printf("\nYes.");
	else 
		printf("\nNo.");
}