#include<stdio.h>
#include<string.h>

int main(void)
{
	char str0[128], str[128], *pStr;
	int i = 0, j = 0, N, num1;

	printf("Input a string:");
	gets(str0);
	printf("\nInput jiange:");
	scanf("%d", &N);

	/* ɾ���ո���� */
	while (str0[i] != '\0')
	{
		if (str0[i] != ' ')
		{
			str[j] = str0[i];
			j++;
		}
		i++;
	}
	str[j] = '\0';
	printf("\nThe string of deleted space:");
	puts(str);

	/* ������� */
	num1 = strlen(str);
	printf("\nThe result is:");
	for (i=0; i<N; i++)
	{
		pStr = str + i;
		while (pStr < str+num1)
		{
			printf("%c", *pStr);
			pStr = pStr + N;
		}
		printf(" ");
	}
	printf("\n");

	return 0;
}
