#include <stdio.h>
#include <string.h>

int main(void)
{
	char str[128], str2[128];

	printf("\nPlease input string:");
	gets(str);

	strcpy(str2, str);
	strrev(str2);
	if (strcmp(str, str2) == 0)
	{
		printf("\n%s shi hui wen.", str);
	}
	else
	{
		printf("\n%s bu shi hui wen.", str);
	}

	return 0;
}
