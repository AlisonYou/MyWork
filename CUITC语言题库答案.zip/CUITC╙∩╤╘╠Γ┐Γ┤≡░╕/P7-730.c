#include <stdio.h>
void main()
{
	int x,y;
	scanf("%d%d",&x,&y);
	if(x==y) printf("yes\n");
		else printf("no\n");
}