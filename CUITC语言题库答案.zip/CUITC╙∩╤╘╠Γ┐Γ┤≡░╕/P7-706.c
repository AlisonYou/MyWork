#include<stdio.h>
void main()
{
	int a[11],i,j,t;
	printf("Please input 10 number:\n");
	for(i=1;i<=10;i++)
		scanf("%d",&a[i]);
	for(j=1;j<=10;j++)
		for(i=1;i<=10-j;i++)
			if(a[i]>a[i+1])
			{
				t=a[i];
				a[i]=a[i+1];
				a[i+1]=t;	
			}
	for(i=1;i<=10;i++)
		printf("%3d",a[i]);
	printf("\n");
}