#include <stdio.h>

int main(void)
{
	unsigned char temp;
	char filein[100], fileout[100];
	FILE *fpin, *fpout;

	printf("Please input sorceFilename: ");
	scanf("%s", filein);
	printf("Please input destinationFilename: ");
	scanf("%s", fileout);
	fpin = fopen(filein, "rb");
	if (fpin == NULL)
	{
		printf("\nsource File (%s) Open Error!\n", filein);
		return 2;
	}
	fpout = fopen(fileout, "wb");
	if (fpout == NULL)
	{
		fclose(fpin);
		printf("\ndestination File (%s) Create Error!\n", fileout);
		return 3;
	}

	fread(&temp, 1, 1, fpin);
	while (!feof(fpin))
	{
		fwrite(&temp, 1, 1, fpout);
		if (ferror(fpout) != 0)
		{
			fclose(fpin);
			fclose(fpout);
			printf("\nwriting destination File (%s) Error!\n", fileout);
			return 4;
		}
		fread(&temp, 1, 1, fpin);
	}

	fclose(fpin);
	fclose(fpout);
	printf("\ncopy %s to %s successed!\n", filein, fileout);
	return 0;
}