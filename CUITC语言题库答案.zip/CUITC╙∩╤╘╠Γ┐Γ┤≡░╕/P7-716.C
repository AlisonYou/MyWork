#include <stdio.h>

void main()
{
	int a,n,count=1;
	double sn=0,tn=0,tmp;
	
	printf("Please input a,n:\n");
	scanf("%d,%d",&a,&n);
	tmp=a;
	while(count<=n)
	{
		tn=tn+tmp;
		sn=sn+tn;
		tmp=tmp*10;
		count++;
	}
	printf("a+aa+...=%.0lf\n",sn);
}
