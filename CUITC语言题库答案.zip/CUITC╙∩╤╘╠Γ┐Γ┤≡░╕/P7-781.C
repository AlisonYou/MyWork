#include <string.h>
#include <stdio.h>

int scmp(char s1[], char s2[])
{
	char c1,c2;
	int i=0;
	do
	{
		c1 = s1[i];
		c2 = s2[i]; 
		if (c1 == '\0') 
			return c1 - c2; 
		i++;
	} 
	while(c1 == c2);
	return c1 - c2; 
}

void scpy(char s1[], char s2[])
{
	int i=0;
	while(s2[i] != '\0')
	{
		s1[i]=s2[i];
		i++;
	}
	s1[i]='\0';
}

void main()
{
	char st[81],name[5][81]; 
	int i,j;
	
	printf("Input 5 strings:\n");
	for(i=0;i<5;i++)  
		gets(name[i]); 
	for(i=1;i<5;i++)
	{
		for(j=0;j<5-i;j++)
		{
			if(scmp(name[j],name[j+1])>0)
			{        
				scpy(st,name[j]);
				scpy(name[j],name[j+1]);
				scpy(name[j+1],st);
			}
		}
	}
	printf("---------------------------\n");
	for(i=0;i<5;i++)  
	{
		puts(name[i]);
		//	 putchar('\n');
	}
} 
