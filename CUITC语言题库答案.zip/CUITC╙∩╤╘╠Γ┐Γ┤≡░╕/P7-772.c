#include<stdio.h>

void Sort(char *str, int num);

int main(void)
{
	char Str[128];
	int i=0, j;

	printf("input the string: \n");
	while (i < 127)
	{
		Str[i] = getchar();
		if ('\n' == Str[i])
		{
			break;
		}
		i++;
	}

	Sort(Str, i);

	printf("\nResult:");
	for (j=0; j<i; j++)
	{
		printf("%c", Str[j]);
	}
	printf("\n");

	return 0;
}

void Sort(char str[], int num)
{
	int i, j, minPos;
	char tmp;

	for (i=0; i<num-1; i++)
	{
		minPos = i;
		for (j=i+1; j<num; j++)
		{	
			if (str[j] < str[minPos])
			{
				minPos = j;
			}
		}

		tmp = str[i];
		str[i] = str[minPos];
		str[minPos] = tmp;
	}
}
