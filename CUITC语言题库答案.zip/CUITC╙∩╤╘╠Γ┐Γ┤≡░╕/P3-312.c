#include <stdio.h>
#include <string.h>

struct good
{
	char name[20];
	char type[12];
	long number;
	float price;
};

int main(void)
{
	int i = 0, n, flag;
	char str[20];
	struct good goods[100];
	FILE *fp;

	fp = fopen("sp.dat", "rb");
	while (!feof(fp))
	{
		fread(&goods[i], sizeof(struct good), 1, fp);
		i++;
	}
	n = i;
	flag = 0;
	printf("Please input shang pin pin ming:");
	scanf("%s", str);
	printf("\ncha zhao qing kuang:\n");
	for (i = 0; i < n; i++)
	{
		if (strcmp(goods[i].name, str)==0)
		{
			printf("%s,%s,%ld,%.2f\n", goods[i].name, goods[i].type,
				goods[i].number, goods[i].price);
			flag = 1;
		}
	}
	if (flag == 0)
	{
		printf("mei you shang pin %s\n", str);
	}
	return 0;
}