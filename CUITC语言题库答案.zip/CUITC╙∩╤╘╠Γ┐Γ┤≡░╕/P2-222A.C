#include <stdio.h>
#include <string.h>

int main(void)
{
	int i = 0;
	char str[128];
	char mmBiaoAZ[] = "ZYXWVUTSRQPONMLKJIHGFEDCBA";
	char mmBiao_az[] = "zyxwvutsrqponmlkjihgfedcba";

	printf("Please input string: ");
	gets(str);

	while (str[i] != '\0')
	{
		if (str[i]>='a' && str[i]<='z')
		{
			str[i] = mmBiao_az[str[i] - 'a'];
		}
		else if (str[i]>='A' && str[i]<='Z')
		{
			str[i] = mmBiaoAZ[str[i] - 'A'];
		}
		i++;
	}

	printf("\nzi fu chuan chang du:%d", strlen(str));
	printf("\nmi wen:");
	puts(str);

	return 0;
}
