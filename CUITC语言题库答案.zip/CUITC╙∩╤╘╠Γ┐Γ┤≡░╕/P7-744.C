#include<stdio.h>

void main()
{
	float score;
	int temp;
	char grade;
	do
	{
		printf("please input the score(0-100):\n");
		scanf("%f",&score);
	}while(score>100||score<0);
	temp=(int)score/10;
	switch(temp)
	{ 
	case 10:
	case  9: grade='A';break;
	case  8: grade='B';break;
	case  7: grade='C';break;
	case  6: grade='D';break;
	default:   grade='E';
	}
	printf("score=%.1f,grade=%c\n",score,grade);
} 
