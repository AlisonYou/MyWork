#include <stdio.h>
int main()
{
	int m,n,i,cnt=0;
	printf("Input the m,n: ");
	scanf("%d,%d",&m,&n);
	printf("The result:\n");
	for( ; cnt<n; m++)
	{
		for(i=2;i<m/2;i++)
		{
			if(m%i==0)
				break;
		}
		if(i==m/2)
		{
			printf("%d ",m);
			cnt++;
		}
	}
}