#include <stdio.h>
int main()
{
	int y,m,d;
	int i;
	long sum=0;
	scanf("%d-%d-%d",&y,&m,&d);
	for(i=1;i<y;i++)
	{
		if(i%4==0&&i%100!=0||i%400==0)
			sum+=366;
		else
			sum+=365;
	}

	switch(m)
	{
	case 2:
		sum+=31;break;
	case 3:
		sum+=59;break;
	case 4:
		sum+=90;break;
	case 5:
		sum+=120;break;
	case 6:
		sum+=151;break;
	case 7:
		sum+=181;break;
	case 8:
		sum+=212;break;
	case 9:
		sum+=243;break;
	case 10:
		sum+=273;break;
	case 11:
		sum+=304;break;
	case 12:
		sum+=334;break;
	}

	sum=sum+d;
	if((y%4==0&&y%100!=0||y%400==0)&&m>2)
		sum++;

	printf("The result is %ld.\n",sum);
}