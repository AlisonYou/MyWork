#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	FILE *fpSrc, *fpDst;
	int cLetter, haveErr=0;

	/* User Code Begin(�������ڱ��к����Ӵ��룬��������) */
	if (argc != 3)
	{	
		printf(" \nusage:P7-764  sourceFilename  destinationFilename\n");
		exit(1);
	}
	fpSrc = fopen(argv[1], "rb");
	if (!fpSrc)
	{
		printf(" \nsource File (%s) Open Error!\n", argv[1]);
		exit(2);
	}
	fpDst = fopen(argv[2], "wb");
	if (!fpDst)
	{
		printf(" \ndestination File (%s) Create Error!\n", argv[2]);
		fclose(fpSrc);
		exit(3);
	}
	cLetter = 0;
	while (1)
	{
		//fputc(fgetc(fpSrc),fpDst);
		fread(&cLetter, 1, 1, fpSrc);
		
		if (feof(fpSrc))
		{
			break;
		}
		if (!fwrite(&cLetter, 1, 1, fpDst))
		{
			printf(" \nwriting destination File (%s) Error!\n", argv[2]);
			fclose(fpSrc);
			fclose(fpDst);
			exit(4);
		}
	}
	fclose(fpSrc);
	fclose(fpDst);
	printf("\ncopy %s to %s successed!\n", argv[1], argv[2]);
	/* User Code End(�������Ӵ������) */

	return 0;
}
