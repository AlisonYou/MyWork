#include <stdio.h>

void main()
{
	int y,m,n;
	
	printf("please input a date:");
	scanf("%d-%d-%d",&y,&m,&n);
	printf("the date is:%d/%d/%d\n",y,m,n);
}