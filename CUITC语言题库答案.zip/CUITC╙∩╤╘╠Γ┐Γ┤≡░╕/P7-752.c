#include <stdio.h>

int main(void)
{
	int i, m, n, tmp;

	printf("Input m, n: ");
	scanf("%d,%d", &m, &n);
	if (m > n)
	{
		tmp = m;
		m = n;
		n = tmp;
	}

	for (i=m; i<=n; i++)
	{
		if (i % 3 == 0 && (i / 100 == 5 || i / 10 % 10 == 5 || i % 10 == 5))
		{
			printf("%d ", i);
		}
	}

	return 0;
}
