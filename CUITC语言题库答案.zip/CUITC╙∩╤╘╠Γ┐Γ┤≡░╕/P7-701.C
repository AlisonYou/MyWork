#include<stdio.h>
#include<string.h>

int main()
{

	int a[10];
	int i,num,flag=0;
	printf("Please input 10 numbers:\n");
	//��������
	for(i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
		if(i!=0)
		{
			if(a[i]<a[i-1])
			{
				i--;
			}
		}
	}
	//���
	printf("\nOutput:\n");
	for(i=0;i<10;i++)
	{
		printf("%5d",a[i]);
		if((i+1)%10==0)
			printf("\n");
		else
			printf(",");
	}

	printf("input the num to look for:\n");
	scanf("%d",&num);
	//����
	for(i=0;i<10;i++)
	{
		if(num==a[i])
		{
			flag=i+1;
			break;
		}
	}

	if(flag)
		printf("the position of %d is %d\n",a[i],flag);
	else
		printf("Not Find!\n");


	return 0;
}