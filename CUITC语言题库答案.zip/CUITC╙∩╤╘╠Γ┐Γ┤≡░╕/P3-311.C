#include<stdio.h>
#include<string.h>

int main()
{

	char s1[128],s2[128],s3[256];
	unsigned int i,min_len,max_len;
	printf("Please input string1:");
	gets(s1);
	printf("Please input string2:");
	gets(s2);
	if(strlen(s1)>strlen(s2))
	{
		min_len=strlen(s2);
		max_len=strlen(s1);
	}
	else
	{
		min_len=strlen(s1);
		max_len=strlen(s2);
	}

	for(i=0;i<min_len;i++)
	{
		if(s1[i]!='\0')
			s3[2*i]=s1[i];
		if(s2[i]!='\0')
			s3[2*i+1]=s2[i];
	}

	for(i=2*min_len;i<strlen(s2)+strlen(s1);i++)
	{
		if(max_len==strlen(s1))
			s3[i]=s1[min_len++];
		else
			s3[i]=s2[min_len++];
	}

	s3[i]='\0';

	printf("\nstring1:%s\n",s3);
	return 0;
}