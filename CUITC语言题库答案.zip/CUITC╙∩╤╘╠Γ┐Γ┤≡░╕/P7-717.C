#include <stdio.h>

void main()
{
	int a[10],i,count=0;
	int b[5],j=0;
                   
	for (i=0; i<5; i++) b[i]=-1;
	printf("Input 10 integers.\n");
	for (i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
		if ((i%2==1)&&(a[i]%2==1)) {b[j++]=i;count++;}
	}
	printf("count=%d\n",count);
	for (i=0; i<j; i++)
		if (b[i]!=-1) printf("a[%d]=%d\n",b[i],a[b[i]]);
                    
}
	