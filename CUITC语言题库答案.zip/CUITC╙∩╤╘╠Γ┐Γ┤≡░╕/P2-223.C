#include<stdio.h>
#include<string.h>

int main()
{
	double sn=0,hn=10000;
	int n;
	int i;

	printf("Please input n:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		sn = sn+1.5*hn;	
		hn=hn/2;
			
	}
	sn=sn-hn;
	printf("sn=%f,hn=%lf\n",sn,hn);


	return 0;
}