#include <stdio.h>

void main()
{ 
	int lenth=0;
	char a[101],c;

	printf("input a string:");
	c=(char)getchar();
	while(c!='\n' && c!=EOF)
	{
		if(lenth<100)
			a[lenth++]=c;
		c=(char)getchar();
	}
	a[lenth]='\0';
	
	printf("\nThe string lenth is:%d\n",lenth);
	printf("The string is:%s\n",a);
}
