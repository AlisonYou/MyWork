#include <stdio.h>
void main()

{  
	int i=0,n;
	printf("please input n: ");
	scanf("%d",&n);
   while (i<n)
   {
	   printf("* * * * *\n");
		i++;
	}
}
