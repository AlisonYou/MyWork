#include <stdio.h>

int main()
{
	int n;
	int s1,s2,s3,s4,sum;
	printf("Input a number with 4-digit: ");
	scanf("%d",&n);
	s1=n/1000;
	s2=n/100%10;
	s3=n/10%10;
	s4=n%10;
	sum=s1+s2+s3+s4;
	printf("sum=%d\n",sum);
}