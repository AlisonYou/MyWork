#include <stdio.h>
int main()
{
	int side;
	int vol, area;
	printf("Input a side of cube: ");
	scanf("%d",&side);
	vol=side*side*side;
	area=6*(side*side);
	printf("The volume of cube is %d, the surface area of cube is %d.\n", vol, area);
}